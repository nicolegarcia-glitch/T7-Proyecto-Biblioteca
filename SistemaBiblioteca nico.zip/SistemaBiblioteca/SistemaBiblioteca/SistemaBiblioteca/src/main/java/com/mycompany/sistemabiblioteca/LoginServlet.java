package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.UsuarioDAO;
import com.biblioteca.model.Usuario;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private final UsuarioDAO dao = new UsuarioDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String rut = request.getParameter("rut");
        String password = request.getParameter("password");

        Usuario usuario = dao.validarUsuario(rut, password);

        if (usuario != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("usuario", usuario);

            switch (usuario.getTipo().toLowerCase()) {
                case "estudiante":
                    response.sendRedirect("cubiculos.jsp");
                    break;
                case "funcionario":
                    response.sendRedirect("Funcionarios.jsp");
                    break;
                case "administrador":
                    response.sendRedirect("Funcionarios.jsp");
                    break;
                default:
                    response.sendRedirect("home.jsp");
                    break;
            }
        } else {
            request.setAttribute("errorMessage", "Usuario o contraseña inválidos.");
            request.getRequestDispatcher("Login.jsp").forward(request, response);
        }
    }
}
