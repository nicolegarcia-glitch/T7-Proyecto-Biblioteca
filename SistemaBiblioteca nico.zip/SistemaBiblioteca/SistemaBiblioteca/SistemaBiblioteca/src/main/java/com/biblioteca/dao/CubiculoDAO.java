package com.biblioteca.dao;

import com.biblioteca.model.Cubiculo;
import java.sql.*;
import java.util.*;

public class CubiculoDAO {

    // Método para contar cubículos disponibles (pendiente de implementación)
    public static int contarDisponibles() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // Listar cubículos disponibles
    public List<Cubiculo> listarCubiculosDisponibles() {
        List<Cubiculo> lista = new ArrayList<>();
        String sql = "SELECT * FROM cubiculos WHERE disponibilidad = true";

        try (Connection con = Conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cubiculo c = new Cubiculo();
                c.setId(rs.getInt("id"));                // id autoincremental
                c.setNumero(rs.getInt("numero"));        // número de cubículo
                c.setCapacidad(rs.getInt("capacidad"));  // capacidad máxima
                c.setPiso(rs.getString("piso"));         // ubicación física
                c.setDisponibilidad(rs.getBoolean("disponibilidad")); // activado o no
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // importante para depuración
        }
        return lista;
    }

    // Método para obtener cubículos por bloque (pendiente de implementación)
    public List<Cubiculo> obtenerCubiculosDisponiblesPorBloque(int id) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    // Insertar nuevo cubículo (RF-002)
    public static boolean insertarCubiculo(Cubiculo cubiculo) {
        String sql = "INSERT INTO cubiculos (numero, capacidad, piso, disponibilidad) VALUES (?, ?, ?, ?)";
        try (Connection conn = Conexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cubiculo.getNumero());
            stmt.setInt(2, cubiculo.getCapacidad());
            stmt.setString(3, cubiculo.getPiso());
            stmt.setBoolean(4, cubiculo.isDisponibilidad());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace(); // mostrar error si falla
            return false;
        }
    }
}
