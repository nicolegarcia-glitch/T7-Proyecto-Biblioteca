package com.mycompany.sistemabiblioteca;

import java.sql.*;

public class UsuarioDAO {
    public boolean validarLogin(String rut, String contrasena) {
        boolean acceso = false;
        Connection con = DBConnection.getConnection();

        if (con == null) {
            System.out.println("? No se pudo conectar a la base de datos");
            return false;
        }

        String sql = "SELECT * FROM usuarios WHERE rut = ? AND contrasena = ?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rut);
            ps.setString(2, contrasena);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                acceso = true;
            }

            rs.close();
        } catch (SQLException e) {
            System.out.println("? Error al validar login:");
            e.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println("? Error al cerrar conexi�n:");
                e.printStackTrace();
            }
        }

        return acceso;
    }
}
