package com.mycompany.sistemabiblioteca;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection getConnection() {
        Connection con = null;
        try {
            // Cargar el driver actualizado
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establecer la conexi�n
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/biblioteca?useSSL=false&serverTimezone=America/Santiago",
                "root", // ? tu usuario de MySQL
                "123456" // ? tu contrase�a real de MySQL
            );
        } catch (Exception ex) {
            System.out.println("? Error de conexi�n a la base de datos:");
            ex.printStackTrace();
        }
        return con;
    }
}

