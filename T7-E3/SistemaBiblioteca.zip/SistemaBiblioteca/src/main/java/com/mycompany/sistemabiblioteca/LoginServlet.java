package com.mycompany.sistemabiblioteca;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String rut = request.getParameter("rut");
        String contrasena = request.getParameter("contrase�a");
        String tipo = request.getParameter("tipo");

        // ?? Se ignora la validaci�n de UsuarioDAO
        HttpSession sesion = request.getSession();
        sesion.setAttribute("rut", rut);
        sesion.setAttribute("tipo", tipo);

        // ? Redirige siempre a cubiculos.jsp
        response.sendRedirect("cubiculos.jsp");
    }
}
