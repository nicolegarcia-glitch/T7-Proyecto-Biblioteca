package com.mycompany.sistemabiblioteca;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ConfirmarReservaServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        String rut = (session != null) ? (String) session.getAttribute("rut") : null;
        String cubiculoId = request.getParameter("cubiculo_id");
        String[] bloques = request.getParameterValues("bloques");

        if (rut == null || cubiculoId == null || bloques == null || bloques.length == 0 || bloques.length > 2) {
            response.sendRedirect("cubiculos.jsp");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO reservas (rut, cubiculo_id, bloque_id, fecha) VALUES (?, ?, ?, CURDATE())"
            );

            for (String bloqueId : bloques) {
                ps.setString(1, rut);
                ps.setString(2, cubiculoId);
                ps.setString(3, bloqueId);
                ps.executeUpdate();
            }

            ps.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("confirmacion.jsp");
    }
}
