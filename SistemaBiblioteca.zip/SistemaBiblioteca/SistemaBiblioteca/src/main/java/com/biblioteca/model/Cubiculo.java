package com.biblioteca.model;

public class Cubiculo {
    private int id;                  // Identificador único en la BD
    private int numero;              // Número de cubículo (entrada RF-002)
    private int capacidad;           // Capacidad máxima de personas
    private String piso;             // Piso de la biblioteca
    private boolean disponibilidad;  // Estado de activación (true = activo)

    // Constructor vacío (necesario para frameworks y JSP/Servlets)
    public Cubiculo() {}

    // Constructor para registro de cubículo (RF-002)
    public Cubiculo(int numero, int capacidad, String piso, boolean disponibilidad) {
        this.numero = numero;
        this.capacidad = capacidad;
        this.piso = piso;
        this.disponibilidad = disponibilidad;
    }

    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getNumero() { return numero; }
    public void setNumero(int numero) { this.numero = numero; }

    public int getCapacidad() { return capacidad; }
    public void setCapacidad(int capacidad) { this.capacidad = capacidad; }

    public String getPiso() { return piso; }
    public void setPiso(String piso) { this.piso = piso; }

    public boolean isDisponibilidad() { return disponibilidad; }
    public void setDisponibilidad(boolean disponibilidad) { this.disponibilidad = disponibilidad; }
}
