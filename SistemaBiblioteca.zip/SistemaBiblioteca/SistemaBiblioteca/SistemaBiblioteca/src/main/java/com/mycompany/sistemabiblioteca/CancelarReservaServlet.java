package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.BDConnection;
import com.biblioteca.model.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/CancelarReservaServlet")
public class CancelarReservaServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        Usuario usuario = (sesion != null) ? (Usuario) sesion.getAttribute("usuario") : null;

        if (usuario == null || !"estudiante".equalsIgnoreCase(usuario.getTipo())) {
            response.sendRedirect("Login.jsp");
            return;
        }

        String reservaParam = request.getParameter("reservaId");
        if (reservaParam == null || reservaParam.isEmpty()) {
            response.sendRedirect("error.jsp");
            return;
        }

        int reservaId = Integer.parseInt(reservaParam);

        try (Connection con = BDConnection.getConnection()) {
            String sql = "DELETE FROM reservas WHERE id = ? AND usuario_id = ?";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, reservaId);
                ps.setInt(2, usuario.getId());
                int filas = ps.executeUpdate();

                if (filas > 0) {
                    // Reserva cancelada correctamente
                    response.sendRedirect("MisReservas.jsp");
                } else {
                    // No se encontró la reserva o no pertenece al usuario
                    response.sendRedirect("error.jsp");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
