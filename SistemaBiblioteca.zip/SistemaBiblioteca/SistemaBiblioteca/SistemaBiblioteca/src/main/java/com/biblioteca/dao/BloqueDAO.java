package com.biblioteca.dao;

import com.biblioteca.model.Bloque;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BloqueDAO {

    public List<Bloque> obtenerBloques() {
        List<Bloque> bloques = new ArrayList<>();
        String sql = "SELECT id, letra, hora_inicio, hora_fin FROM bloques";

        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Bloque b = new Bloque();
                b.setId(rs.getInt("id"));
                b.setLetra(rs.getString("letra"));
                b.setHoraInicio(rs.getTime("hora_inicio").toString());
                b.setHoraFin(rs.getTime("hora_fin").toString());
                bloques.add(b);
            }
        } catch (SQLException e) {
            System.err.println("⚠ Error al obtener bloques: " + e.getMessage());
        }

        return bloques;
    }
}
