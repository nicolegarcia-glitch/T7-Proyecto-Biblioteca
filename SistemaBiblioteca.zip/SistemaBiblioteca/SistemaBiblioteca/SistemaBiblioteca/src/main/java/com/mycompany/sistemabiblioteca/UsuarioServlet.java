package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.UsuarioDAO;
import com.biblioteca.model.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/UsuarioServlet")
public class UsuarioServlet extends HttpServlet {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("crear".equalsIgnoreCase(action)) {
            Usuario u = new Usuario();
            u.setRut(request.getParameter("rut"));
            u.setNombre(request.getParameter("nombre"));
            u.setApellido(request.getParameter("apellido"));
            u.setCorreo(request.getParameter("correo"));
            u.setPassword(request.getParameter("password"));
            u.setTipo(request.getParameter("tipo"));

            usuarioDAO.crearUsuario(u);

        } else if ("modificar".equalsIgnoreCase(action)) {
            Usuario u = new Usuario();
            u.setRut(request.getParameter("rut"));
            u.setNombre(request.getParameter("nombre"));
            u.setApellido(request.getParameter("apellido"));
            u.setCorreo(request.getParameter("correo"));
            u.setPassword(request.getParameter("password"));
            u.setTipo(request.getParameter("tipo"));

            usuarioDAO.modificarUsuario(u);

        } else if ("eliminar".equalsIgnoreCase(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            usuarioDAO.eliminarUsuario(id);
        }

        // Redirigir siempre a la lista de usuarios
        response.sendRedirect("usuarios.jsp");
    }
}
