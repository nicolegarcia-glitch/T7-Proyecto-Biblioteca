package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.BDConnection;
import java.sql.Connection;

public class TestConnection {
    public static void main(String[] args) {
        Connection con = BDConnection.getConnection();
        if (con != null) {
            System.out.println("Conexion OK");
        } else {
            System.out.println("Conexion fallida");
        }
    }
}
