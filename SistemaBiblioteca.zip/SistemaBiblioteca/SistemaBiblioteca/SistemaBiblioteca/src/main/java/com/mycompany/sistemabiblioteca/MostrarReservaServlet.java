package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.BloqueDAO;
import com.biblioteca.model.Bloque;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/MostrarReservaServlet")
public class MostrarReservaServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuario") == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        String idCubiculo = request.getParameter("id");
        List<Bloque> bloques = new BloqueDAO().obtenerBloques();

        request.setAttribute("idCubiculo", idCubiculo);
        request.setAttribute("bloques", bloques);

        request.getRequestDispatcher("bloquesDisponibles.jsp").forward(request, response);
    }
}
