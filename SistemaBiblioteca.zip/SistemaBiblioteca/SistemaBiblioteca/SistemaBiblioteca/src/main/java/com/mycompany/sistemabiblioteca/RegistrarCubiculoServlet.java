package com.mycompany.sistemabiblioteca;

import com.biblioteca.model.Cubiculo;
import com.biblioteca.dao.CubiculoDAO;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.io.IOException;

@WebServlet("/RegistrarCubiculoServlet")
public class RegistrarCubiculoServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String numeroStr = request.getParameter("numero");
        String capacidadStr = request.getParameter("capacidad");
        String piso = request.getParameter("piso");
        String disponibilidadStr = request.getParameter("disponibilidad");

        // Validación básica
        if (numeroStr == null || capacidadStr == null || piso == null || disponibilidadStr == null) {
            request.setAttribute("mensaje", "Error: faltan datos obligatorios.");
            request.getRequestDispatcher("confirmacion.jsp").forward(request, response);
            return;
        }

        int numero = Integer.parseInt(numeroStr);
        int capacidad = Integer.parseInt(capacidadStr);
        boolean disponibilidad = Boolean.parseBoolean(disponibilidadStr);

        Cubiculo cubiculo = new Cubiculo(numero, capacidad, piso, disponibilidad);
        boolean exito = CubiculoDAO.insertarCubiculo(cubiculo);

        request.setAttribute("numero", numero);
        request.setAttribute("capacidad", capacidad);
        request.setAttribute("piso", piso);
        request.setAttribute("disponibilidad", disponibilidad);
        request.setAttribute("mensaje", exito ? "Cubículo registrado correctamente." : "Error al registrar cubículo.");

        request.getRequestDispatcher("confirmacion.jsp").forward(request, response);
    }
}
