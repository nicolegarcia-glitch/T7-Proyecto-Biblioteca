package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.reservaDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/GestionReservasServlet")
public class GestionReservasServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        reservaDAO dao = new reservaDAO();

        try {
            if ("eliminar".equals(accion)) {
                int id = Integer.parseInt(request.getParameter("id"));
                dao.eliminarReserva(id);
                request.setAttribute("mensaje", "✅ Reserva eliminada correctamente");
            }
        } catch (Exception e) {
            request.setAttribute("mensaje", "⚠ Error en gestión de reserva: " + e.getMessage());
        }

        request.getRequestDispatcher("reservas.jsp").forward(request, response);
    }
}
