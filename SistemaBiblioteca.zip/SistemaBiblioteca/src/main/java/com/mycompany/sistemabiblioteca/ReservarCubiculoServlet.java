
import com.biblioteca.dao.BloqueDAO;
import com.biblioteca.dao.CubiculoDAO;
import com.biblioteca.model.Bloque;
import com.biblioteca.model.Cubiculo;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/ReservarCubiculoServlet")
public class ReservarCubiculoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        if (sesion == null || sesion.getAttribute("usuario") == null) {
            response.sendRedirect("Login.jsp");
            return;
        }

        List<Bloque> bloques = new BloqueDAO().obtenerBloques();
        CubiculoDAO cubiculoDAO = new CubiculoDAO();

        Map<Bloque, List<Cubiculo>> cubiculosPorBloque = new LinkedHashMap<>();
        for (Bloque b : bloques) {
            List<Cubiculo> disponibles = cubiculoDAO.obtenerCubiculosDisponiblesPorBloque(b.getId());
            cubiculosPorBloque.put(b, disponibles);
        }

        request.setAttribute("cubiculosPorBloque", cubiculosPorBloque);
        request.getRequestDispatcher("reservar.jsp").forward(request, response);
    }
}
