package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.UsuarioDAO;
import com.biblioteca.model.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/RegistroServlet")  //  importante para que Tomcat lo encuentre
public class RegistroServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            Usuario usuario = new Usuario();
            usuario.setRut(request.getParameter("rut"));
            usuario.setNombre(request.getParameter("nombre"));
            usuario.setApellido(request.getParameter("apellido"));
            usuario.setCorreo(request.getParameter("correo"));
            usuario.setPassword(request.getParameter("password"));
            usuario.setTipo(request.getParameter("tipo"));

            UsuarioDAO dao = new UsuarioDAO();
            dao.crearUsuario(usuario);

            request.setAttribute("mensaje", "✅ Usuario creado exitosamente");
        } catch (Exception e) {
            request.setAttribute("mensaje", "⚠ Error al registrar usuario: " + e.getMessage());
        }

        request.getRequestDispatcher("resultado.jsp").forward(request, response);
    }
}
