package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.CubiculoDAO;
import com.biblioteca.dao.UsuarioDAO;
import com.biblioteca.model.Cubiculo;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/estadisticasServlet")
public class estadisticasServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int totalUsuarios = UsuarioDAO.contarUsuarios();
        CubiculoDAO cubiculoDAO = new CubiculoDAO();

        int totalCubiculos = cubiculoDAO.contarCubiculos();
        int totalCubiculosDisponibles = cubiculoDAO.contarCubiculosDisponibles();

        // Pasamos los atributos al JSP
        request.setAttribute("totalUsuarios", totalUsuarios);
        request.setAttribute("totalCubiculos", totalCubiculos);
        request.setAttribute("totalCubiculosDisponibles", totalCubiculosDisponibles);

        request.getRequestDispatcher("Estadisticas.jsp").forward(request, response);
        
        Cubiculo cubiculoMasArrendado = cubiculoDAO.obtenerCubiculoMasArrendado();
request.setAttribute("cubiculoMasArrendado", cubiculoMasArrendado);

    }
}
