package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.CubiculoDAO;
import com.biblioteca.model.Cubiculo;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/RegistrarCubiculoServlet")
public class RegistrarCubiculoServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int capacidad = Integer.parseInt(request.getParameter("capacidad"));
if (capacidad > 5) {
    request.setAttribute("mensaje", "⚠ La capacidad máxima permitida es 5");
    request.getRequestDispatcher("registrarCubiculo.jsp").forward(request, response);
    return;
}

        int piso = Integer.parseInt(request.getParameter("piso"));
        String disponibilidad = request.getParameter("disponibilidad").equals("true") ? "Disponible" : "No disponible";

        Cubiculo cubiculo = new Cubiculo();
        cubiculo.setCapacidad(capacidad);
        cubiculo.setPiso(piso);
        cubiculo.setDisponibilidad(disponibilidad);

        CubiculoDAO dao = new CubiculoDAO();
        boolean registrado = dao.registrarCubiculo(cubiculo);

        request.setAttribute("mensaje", registrado ? "✅ Cubículo registrado correctamente" : "⚠ Error al registrar cubículo");
        request.setAttribute("capacidad", capacidad);
        request.setAttribute("piso", piso);
        request.setAttribute("disponibilidad", disponibilidad);

        request.getRequestDispatcher("confirmacionCubiculo.jsp").forward(request, response);
    }
}
