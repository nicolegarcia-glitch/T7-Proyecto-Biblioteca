package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.CubiculoDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/EliminarCubiculoServlet")
public class EliminarCubiculoServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        CubiculoDAO dao = new CubiculoDAO();
        boolean eliminado = dao.eliminarCubiculo(id);

        request.setAttribute("mensaje", eliminado ? "✅ Cubículo eliminado correctamente" : "⚠ Error al eliminar cubículo");

        // Redirige de nuevo a la página de registro para refrescar la lista
        request.getRequestDispatcher("registrarCubiculo.jsp").forward(request, response);
    }
}
