package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.BDConnection;
import com.biblioteca.model.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ReservarServlet")
public class ReservarServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession sesion = request.getSession(false);
        Usuario usuario = (sesion != null) ? (Usuario) sesion.getAttribute("usuario") : null;

        if (usuario == null || !"estudiante".equalsIgnoreCase(usuario.getTipo())) {
            response.sendRedirect("Login.jsp");
            return;
        }

        String cubiculoParam = request.getParameter("idCubiculo");
        String bloqueParam = request.getParameter("bloqueId");

        if (cubiculoParam == null || bloqueParam == null || cubiculoParam.isEmpty() || bloqueParam.isEmpty()) {
            response.sendRedirect("errorBloque.jsp");
            return;
        }

        int idCubiculo = Integer.parseInt(cubiculoParam);
        int bloqueId = Integer.parseInt(bloqueParam);

        try (Connection con = BDConnection.getConnection()) {
            // 1. Verificar límite de reservas por usuario
            int cantidadReservas = 0;
            try (PreparedStatement psCount = con.prepareStatement(
                    "SELECT COUNT(*) FROM reservas WHERE usuario_id = ?")) {
                psCount.setInt(1, usuario.getId());
                try (ResultSet rsCount = psCount.executeQuery()) {
                    if (rsCount.next()) cantidadReservas = rsCount.getInt(1);
                }
            }
            if (cantidadReservas >= 2) {
                response.sendRedirect("limiteReservas.jsp");
                return;
            }

            // 2. Verificar si el usuario ya reservó ese cubículo en ese bloque y fecha
            boolean yaReservadoPorUsuario = false;
            try (PreparedStatement psCheck = con.prepareStatement(
                    "SELECT COUNT(*) FROM reservas WHERE usuario_id = ? AND cubiculo_id = ? AND bloque_id = ? AND fecha = CURDATE()")) {
                psCheck.setInt(1, usuario.getId());
                psCheck.setInt(2, idCubiculo);
                psCheck.setInt(3, bloqueId);
                try (ResultSet rsCheck = psCheck.executeQuery()) {
                    if (rsCheck.next() && rsCheck.getInt(1) > 0) yaReservadoPorUsuario = true;
                }
            }
            if (yaReservadoPorUsuario) {
                response.sendRedirect("cubiculoOcupado.jsp"); // mensaje: "Ya reservaste este cubículo en ese bloque"
                return;
            }

            // 3. Verificar si el cubículo ya está ocupado por otro usuario en ese bloque y fecha
            boolean cubiculoOcupado = false;
            try (PreparedStatement psCheckCubiculo = con.prepareStatement(
                    "SELECT COUNT(*) FROM reservas WHERE cubiculo_id = ? AND bloque_id = ? AND fecha = CURDATE()")) {
                psCheckCubiculo.setInt(1, idCubiculo);
                psCheckCubiculo.setInt(2, bloqueId);
                try (ResultSet rsCheckCubiculo = psCheckCubiculo.executeQuery()) {
                    if (rsCheckCubiculo.next() && rsCheckCubiculo.getInt(1) > 0) cubiculoOcupado = true;
                }
            }
            if (cubiculoOcupado) {
                response.sendRedirect("cubiculoYaReservado.jsp"); // mensaje: "Este cubículo ya está ocupado en ese bloque"
                return;
            }

            // 4. Insertar nueva reserva
            try (PreparedStatement psInsert = con.prepareStatement(
                    "INSERT INTO reservas (usuario_id, cubiculo_id, bloque_id, fecha) VALUES (?, ?, ?, CURDATE())")) {
                psInsert.setInt(1, usuario.getId());
                psInsert.setInt(2, idCubiculo);
                psInsert.setInt(3, bloqueId);
                psInsert.executeUpdate();
            }

            response.sendRedirect("confirmacion.jsp");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
