package com.mycompany.sistemabiblioteca;

import com.biblioteca.dao.UsuarioDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/GestionUsuariosServlet")
public class GestionUsuariosServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");
        UsuarioDAO dao = new UsuarioDAO();

        try {
            if ("eliminar".equals(accion)) {
                int id = Integer.parseInt(request.getParameter("id"));
                dao.eliminarUsuario(id);
                request.setAttribute("mensaje", "✅ Usuario eliminado correctamente");
            }
            // aquí podrías agregar "modificar" con dao.modificarUsuario(usuario)
        } catch (Exception e) {
            request.setAttribute("mensaje", "⚠ Error en gestión de usuario: " + e.getMessage());
        }

        request.getRequestDispatcher("usuarios.jsp").forward(request, response);
    }
}
