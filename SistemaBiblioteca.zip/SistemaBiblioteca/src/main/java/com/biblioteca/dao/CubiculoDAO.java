package com.biblioteca.dao;

import com.biblioteca.model.Cubiculo;
import java.sql.*;
import java.util.*;

public class CubiculoDAO {

    // Registrar nuevo cubículo
    public boolean registrarCubiculo(Cubiculo cubiculo) {
        String sql = "INSERT INTO cubiculos (capacidad, piso, disponibilidad) VALUES (?, ?, ?)";
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, cubiculo.getCapacidad());
            ps.setInt(2, cubiculo.getPiso());
            ps.setString(3, cubiculo.getDisponibilidad());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Listar cubículos disponibles
    public List<Cubiculo> listarCubiculosDisponibles() {
        List<Cubiculo> lista = new ArrayList<>();
        String sql = "SELECT * FROM cubiculos WHERE disponibilidad = 'Disponible'";
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cubiculo c = new Cubiculo();
                c.setId(rs.getInt("id"));
                c.setCapacidad(rs.getInt("capacidad"));
                c.setPiso(rs.getInt("piso"));
                c.setDisponibilidad(rs.getString("disponibilidad"));
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    // Eliminar cubículo por ID
    public boolean eliminarCubiculo(int id) {
        String sql = "DELETE FROM cubiculos WHERE id = ?";
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Contar cubículos disponibles
    public int contarCubiculosDisponibles() {
        String sql = "SELECT COUNT(*) FROM cubiculos WHERE disponibilidad = 'Disponible'";
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("⚠ Error al contar cubículos: " + e.getMessage());
        }
        return 0;
    }

    // Contar todos los cubículos registrados
    public int contarCubiculos() {
        String sql = "SELECT COUNT(*) FROM cubiculos";
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("⚠ Error al contar cubículos: " + e.getMessage());
        }
        return 0;
    }

    // Obtener el cubículo más arrendado
public Cubiculo obtenerCubiculoMasArrendado() {
    String sql = "SELECT c.*, COUNT(r.id) AS total_reservas " +
                 "FROM cubiculos c " +
                 "JOIN reservas r ON c.id = r.cubiculo_id " +
                 "GROUP BY c.id, c.capacidad, c.piso, c.disponibilidad " +
                 "ORDER BY total_reservas DESC LIMIT 1";

    try (Connection con = BDConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {
            Cubiculo c = new Cubiculo();
            c.setId(rs.getInt("id"));
            c.setCapacidad(rs.getInt("capacidad"));
            c.setPiso(rs.getInt("piso"));
            c.setDisponibilidad(rs.getString("disponibilidad"));
            // puedes guardar el total de reservas en el modelo si lo agregas
            return c;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null;
}

    
    // Obtener cubículos disponibles por bloque
    public List<Cubiculo> obtenerCubiculosDisponiblesPorBloque(int idBloque) {
        List<Cubiculo> lista = new ArrayList<>();
        String sql = "SELECT c.* FROM cubiculos c " +
                     "JOIN reservas r ON c.id = r.cubiculo_id " +
                     "WHERE r.bloque_id = ? AND c.disponibilidad = 'Disponible'";

        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idBloque);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Cubiculo c = new Cubiculo();
                    c.setId(rs.getInt("id"));
                    c.setCapacidad(rs.getInt("capacidad"));
                    c.setPiso(rs.getInt("piso"));
                    c.setDisponibilidad(rs.getString("disponibilidad"));
                    lista.add(c);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
