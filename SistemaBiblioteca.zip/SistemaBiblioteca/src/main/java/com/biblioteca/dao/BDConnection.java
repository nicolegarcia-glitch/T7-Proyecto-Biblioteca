package com.biblioteca.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BDConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/biblioteca?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";        // tu usuario MySQL
    private static final String PASSWORD = "123456";  // tu contraseña MySQL

    public static Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.err.println("⚠ Driver JDBC no encontrado: " + e.getMessage());
        } catch (SQLException e) {
            System.err.println("⚠ Error de conexión a BD: " + e.getMessage());
        }
        return conn;
    }
}
