package com.biblioteca.dao;

import java.sql.*;

public class reservaDAO {

    // Eliminar reserva por ID
    public void eliminarReserva(int id) {
        String sql = "DELETE FROM reservas WHERE id=?";
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("⚠ Error al eliminar reserva: " + e.getMessage());
        }
    }
}
