package com.biblioteca.dao;

import com.biblioteca.model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    // Contar usuarios
    public static int contarUsuarios() {
        int total = 0;
        String sql = "SELECT COUNT(*) FROM usuarios";

        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                total = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("⚠ Error al contar usuarios: " + e.getMessage());
        }

        return total;
    }

    // Validar login
    public Usuario validarUsuario(String rut, String password) {
        Usuario usuario = null;
        Connection con = BDConnection.getConnection();

        if (con == null) {
            System.err.println("⚠ Conexión fallida.");
            return null;
        }

        String sql = "SELECT id, rut, nombre, tipo FROM usuarios WHERE rut=? AND password=?";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rut);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    usuario = new Usuario();
                    usuario.setId(rs.getInt("id"));
                    usuario.setRut(rs.getString("rut"));
                    usuario.setNombre(rs.getString("nombre"));
                    usuario.setTipo(rs.getString("tipo"));
                }
            }
        } catch (SQLException e) {
            System.err.println("⚠ Error SQL en validarUsuario: " + e.getMessage());
        }

        return usuario;
    }

    // Crear usuario
    public void crearUsuario(Usuario usuario) {
        String sql = "INSERT INTO usuarios (rut, nombre, apellido, correo, password, tipo) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario.getRut());
            ps.setString(2, usuario.getNombre());
            ps.setString(3, usuario.getApellido());
            ps.setString(4, usuario.getCorreo());
            ps.setString(5, usuario.getPassword());
            ps.setString(6, usuario.getTipo());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("⚠ Error al crear usuario: " + e.getMessage());
        }
    }
 // Listar usuarios
    public List<Usuario> listarUsuarios() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setRut(rs.getString("rut"));
                u.setNombre(rs.getString("nombre"));
                u.setApellido(rs.getString("apellido"));
                u.setCorreo(rs.getString("correo"));
                u.setPassword(rs.getString("password"));
                u.setTipo(rs.getString("tipo"));
                lista.add(u);
            }
        } catch (SQLException e) {
            System.err.println("⚠ Error al listar usuarios: " + e.getMessage());
        }
        return lista;
    }
    // Modificar usuario
    public void modificarUsuario(Usuario usuario) {
        String sql = "UPDATE usuarios SET nombre=?, apellido=?, correo=?, password=?, tipo=? WHERE rut=?";

        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setString(3, usuario.getCorreo());
            ps.setString(4, usuario.getPassword());
            ps.setString(5, usuario.getTipo());
            ps.setString(6, usuario.getRut());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("⚠ Error al modificar usuario: " + e.getMessage());
        }
    }

    // Eliminar usuario
    public void eliminarUsuario(int id) {
        String sql = "DELETE FROM usuarios WHERE id=?";

        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("⚠ Error al eliminar usuario: " + e.getMessage());
        }
    }
}
