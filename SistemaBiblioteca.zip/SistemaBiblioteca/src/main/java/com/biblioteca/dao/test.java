/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.biblioteca.dao;

import com.biblioteca.dao.BDConnection;
import java.sql.Connection;

public class test {
    public static void main(String[] args) {
        Connection conn = BDConnection.getConnection();
        if (conn != null) {
            System.out.println("Conexión exitosa");
        } else {
            System.out.println("Error de conexión");
        }
    }
}
