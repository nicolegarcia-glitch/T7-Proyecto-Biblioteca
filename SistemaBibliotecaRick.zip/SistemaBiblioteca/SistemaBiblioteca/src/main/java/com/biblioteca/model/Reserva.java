/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author ricar
 */
package com.biblioteca.model;

import java.time.LocalDate;

public class Reserva {
    private int id;
    private String rut;
    private int cubiculoId;
    private int bloqueId;
    private LocalDate fecha;
    private String estado; // "activa" o "cancelada"

    public Reserva() {}

    public Reserva(String rut, int cubiculoId, int bloqueId, LocalDate fecha, String estado) {
        this.rut = rut;
        this.cubiculoId = cubiculoId;
        this.bloqueId = bloqueId;
        this.fecha = fecha;
        this.estado = estado;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getRut() { return rut; }
    public void setRut(String rut) { this.rut = rut; }

    public int getCubiculoId() { return cubiculoId; }
    public void setCubiculoId(int cubiculoId) { this.cubiculoId = cubiculoId; }

    public int getBloqueId() { return bloqueId; }
    public void setBloqueId(int bloqueId) { this.bloqueId = bloqueId; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
