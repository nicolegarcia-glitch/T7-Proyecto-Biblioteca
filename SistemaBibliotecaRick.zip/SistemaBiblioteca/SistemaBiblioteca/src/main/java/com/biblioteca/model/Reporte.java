/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.biblioteca.model;

public class Reporte {
    private final int totalReservas;          // activas + canceladas
    private final int totalCancelaciones;     // estado = 'cancelada'
    private final double tiempoPromedioHoras; // sobre reservas activas

    public Reporte(int totalReservas, int totalCancelaciones, double tiempoPromedioHoras) {
        this.totalReservas = totalReservas;
        this.totalCancelaciones = totalCancelaciones;
        this.tiempoPromedioHoras = tiempoPromedioHoras;
    }

    public int getTotalReservas() { return totalReservas; }
    public int getTotalCancelaciones() { return totalCancelaciones; }
    public double getTiempoPromedioHoras() { return tiempoPromedioHoras; }
}
