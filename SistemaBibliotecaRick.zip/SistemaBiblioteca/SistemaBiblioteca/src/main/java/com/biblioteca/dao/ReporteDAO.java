/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.biblioteca.dao;

import com.biblioteca.model.Reporte;
import java.sql.*;
import java.time.LocalDate;

public class ReporteDAO {

    private Connection getConnection() throws SQLException {
        return BDConnection.getConnection();
    }

    // Generar reporte con filtros opcionales: rut y tipo de cubículo
    public Reporte generarReporte(LocalDate inicio, LocalDate fin, String rut, String tipoCubiculo) {
        int totalReservas = 0;
        int totalCancelaciones = 0;
        double promedioHoras = 0.0;

        String baseWhere = "r.fecha BETWEEN ? AND ?";
        StringBuilder where = new StringBuilder(baseWhere);
        if (rut != null && !rut.isBlank()) where.append(" AND r.rut = ?");
        if (tipoCubiculo != null && !tipoCubiculo.isBlank()) where.append(" AND c.tipo = ?");

        String sqlTotal = "SELECT COUNT(*) FROM reservas r " +
                          "JOIN cubiculos c ON r.cubiculo_id = c.id " +
                          "WHERE " + where;

        String sqlCancel = "SELECT COUNT(*) FROM reservas r " +
                           "JOIN cubiculos c ON r.cubiculo_id = c.id " +
                           "WHERE " + where + " AND r.estado = 'cancelada'";

        String sqlPromedio = "SELECT AVG(TIMESTAMPDIFF(MINUTE, b.hora_inicio, b.hora_fin))/60 AS horas " +
                             "FROM reservas r " +
                             "JOIN bloques b ON r.bloque_id = b.id " +
                             "JOIN cubiculos c ON r.cubiculo_id = c.id " +
                             "WHERE " + where + " AND r.estado = 'activa'";

        try (Connection con = getConnection()) {
            // Total reservas
            try (PreparedStatement ps = con.prepareStatement(sqlTotal)) {
                int idx = 1;
                ps.setDate(idx++, Date.valueOf(inicio));
                ps.setDate(idx++, Date.valueOf(fin));
                if (rut != null && !rut.isBlank()) ps.setString(idx++, rut);
                if (tipoCubiculo != null && !tipoCubiculo.isBlank()) ps.setString(idx++, tipoCubiculo);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalReservas = rs.getInt(1);
                }
            }
            // Cancelaciones
            try (PreparedStatement ps = con.prepareStatement(sqlCancel)) {
                int idx = 1;
                ps.setDate(idx++, Date.valueOf(inicio));
                ps.setDate(idx++, Date.valueOf(fin));
                if (rut != null && !rut.isBlank()) ps.setString(idx++, rut);
                if (tipoCubiculo != null && !tipoCubiculo.isBlank()) ps.setString(idx++, tipoCubiculo);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) totalCancelaciones = rs.getInt(1);
                }
            }
            // Promedio horas
            try (PreparedStatement ps = con.prepareStatement(sqlPromedio)) {
                int idx = 1;
                ps.setDate(idx++, Date.valueOf(inicio));
                ps.setDate(idx++, Date.valueOf(fin));
                if (rut != null && !rut.isBlank()) ps.setString(idx++, rut);
                if (tipoCubiculo != null && !tipoCubiculo.isBlank()) ps.setString(idx++, tipoCubiculo);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) promedioHoras = rs.getDouble(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return new Reporte(totalReservas, totalCancelaciones, promedioHoras);
    }
}
