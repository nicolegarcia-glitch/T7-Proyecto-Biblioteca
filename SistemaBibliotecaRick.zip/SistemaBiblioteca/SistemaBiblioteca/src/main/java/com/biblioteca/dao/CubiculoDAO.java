package com.biblioteca.dao;

import com.biblioteca.model.Cubiculo;
import java.sql.*;
import java.util.*;

public class CubiculoDAO {

    public static int contarDisponibles() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Cubiculo> listarCubiculosDisponibles() {
        List<Cubiculo> lista = new ArrayList<>();
        try (Connection con = BDConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM cubiculos WHERE disponibilidad = 'Disponible'");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Cubiculo c = new Cubiculo();
                c.setId(rs.getInt("id"));
                c.setCapacidad(rs.getInt("capacidad"));
                c.setPiso(rs.getInt("piso"));
                c.setDisponibilidad(rs.getString("disponibilidad"));
                lista.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Cubiculo> obtenerCubiculosDisponiblesPorBloque(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
private String tipo; // individual, grupal, sala

public String getTipo() { return tipo; }
public void setTipo(String tipo) { this.tipo = tipo; }

}


