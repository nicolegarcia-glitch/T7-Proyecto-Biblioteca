/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.biblioteca.dao;

import com.biblioteca.model.Reserva;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReservaDAO {

    private Connection getConnection() throws SQLException {
        return BDConnection.getConnection(); // usa tu clase de conexión
    }

    // Crear reserva con estado 'activa'
    public int crearReserva(Reserva r) {
        String sql = "INSERT INTO reservas (rut, cubiculo_id, bloque_id, fecha, estado) VALUES (?, ?, ?, ?, 'activa')";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, r.getRut());
            ps.setInt(2, r.getCubiculoId());
            ps.setInt(3, r.getBloqueId());
            ps.setDate(4, Date.valueOf(r.getFecha()));
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) return keys.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    // Cancelar reserva (actualiza estado)
    public boolean cancelarReserva(int idReserva) {
        String sql = "UPDATE reservas SET estado = 'cancelada' WHERE id = ?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idReserva);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Obtener reservas por rut
    public List<Reserva> obtenerReservasPorRut(String rut) {
        List<Reserva> lista = new ArrayList<>();
        String sql = "SELECT id, cubiculo_id, bloque_id, fecha, estado FROM reservas WHERE rut = ? ORDER BY fecha";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, rut);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Reserva r = new Reserva();
                    r.setId(rs.getInt("id"));
                    r.setRut(rut);
                    r.setCubiculoId(rs.getInt("cubiculo_id"));
                    r.setBloqueId(rs.getInt("bloque_id"));
                    r.setFecha(rs.getDate("fecha").toLocalDate());
                    r.setEstado(rs.getString("estado"));
                    lista.add(r);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
