/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.mycompany.sistemabiblioteca.resources;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDate;

import com.biblioteca.dao.ReporteDAO;
import com.biblioteca.model.Reporte;

@WebServlet(name = "ReporteServlet", urlPatterns = {"/ReporteServlet"})
public class ReporteServlet extends HttpServlet {

    private final ReporteDAO reporteDAO = new ReporteDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/reporte.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Validar rol administrador
        Object rol = request.getSession().getAttribute("rol");
        if (rol == null || !"administrador".equals(rol.toString())) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Acceso restringido a administradores.");
            return;
        }

        LocalDate inicio = LocalDate.parse(request.getParameter("fechaInicio"));
        LocalDate fin = LocalDate.parse(request.getParameter("fechaFin"));
        String rut = request.getParameter("rut");
        String tipo = request.getParameter("tipo");

        Reporte reporte = reporteDAO.generarReporte(inicio, fin, rut, tipo);

        request.setAttribute("reporte", reporte);
        request.setAttribute("fechaInicio", inicio.toString());
        request.setAttribute("fechaFin", fin.toString());
        request.setAttribute("rut", rut);
        request.setAttribute("tipo", tipo);

        request.getRequestDispatcher("/reporte.jsp").forward(request, response);
    }
}
